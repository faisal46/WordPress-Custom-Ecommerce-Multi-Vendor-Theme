<?php
   /**
    * The header for our theme
    *
    * Displays all of the <head> section and everything up till <div id="content">
    *
    * @package abdask
    */
   
   // Exit if accessed directly.
   defined( 'ABSPATH' ) || exit;
   
   $container = get_theme_mod( 'abdask_container_type' );
   ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
   <head>
      <meta charset="<?php bloginfo( 'charset' ); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="profile" href="<?php echo esc_url( 'http://gmpg.org/xfn/11' ); ?>">
      <link rel="preconnect" href="https://fonts.gstatic.com">
	   <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
      <?php wp_head(); ?>
      <?php if( is_admin_bar_showing() ){ ?>
      <style type="text/css">.fixed-top { top: 32px; }</style>
      <?php } ?>
      <?php if( !is_user_logged_in() ){ ?>
      <style type="text/css">
         @media (min-width: 320px) and (max-width: 480px) {
         .custom-logo-link img {
         width: 90px;
         }
         .custom-logo-link{
         padding: 0;
         margin-left: -65px;
         margin-right: -12px;
         }
         #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-box {
         margin-top: -25px;
         }
         #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner, #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner::before, #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-inner::after {
         width: 20px;
         height: 2px;
         }
         .abdask-login-button-mobile {
         margin-right: -20px;
         }
         }
      </style>
      <?php } else {?>
      <style type="text/css">
      @media (max-width: 1024px) and (min-width: 768px){
       .abdask-login-button {
          width: 0 !important;
        }
        
      }
         @media (min-width: 320px) and (max-width: 480px) {
         #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-box {
         margin-top: 0px !important;
         }
         .abdask-product-menu{
         margin-top: 129px;
         }   
         }
         .
      </style>
      <?php }
         if ( current_user_can( 'administrator' ) ) { ?>
      <style type="text/css">
      @media (max-width: 1024px) and (min-width: 768px){
       .abdask-login-button {
          width: 0 !important;
        }
        
      }
      
      @media (max-width: 767px) and (min-width: 481px){
       #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-box {
        margin-left: -167px;
        margin-top: 71px !important;
      }

    }
         @media (min-width: 320px) and (max-width: 480px) {
         #mega-menu-wrap-product-menu .mega-menu-toggle .mega-toggle-block-0 .mega-toggle-animated-box {
         margin-top: 85px  !important;
		margin-left: -168px !important;
         }
         .abdask-product-menu {
         margin-top: 114px;
         }
         }
      </style>
      <?php } ?>
   </head>
   <body <?php body_class(); ?> <?php abdask_body_attributes(); ?>>
      <?php do_action( 'wp_body_open' ); ?>
      <div class="site" id="page">
      <!-- ******************* The Navbar Area ******************* -->
      <div id="wrapper-navbar">
         <a class="skip-link sr-only sr-only-focusable"
            href="#content"><?php esc_html_e( 'Skip to content', 'abdask' ); ?></a>
         <nav id="main-nav" class="navbar navbar-expand-md navbar-dark fixed-top abdask-header" aria-labelledby="main-nav-label">
            <div class="container">
               <h2 id="main-nav-label" class="sr-only">
                  <?php esc_html_e( 'Main Navigation', 'abdask' ); ?>
               </h2>
               <?php if ( 'container' === $container ) : ?>
               <div class="container">
                  <?php endif; ?>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#product-menu"
                     aria-controls="product-menu" aria-expanded="false"
                     aria-label="<?php esc_attr_e( 'Toggle navigation', 'abdask' ); ?>">
                     <!-- <span class="navbar-toggler-icon"></span> -->
                  </button>
                  <!-- Your site title as branding in the menu -->
                  <?php if ( ! has_custom_logo() ) { ?>
                  <?php if ( is_front_page() && is_home() ) : ?>
                  <h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>"
                     title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"
                     itemprop="url"><?php bloginfo( 'name' ); ?></a></h1>
                  <?php else : ?>
                  <a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>"
                     title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"
                     itemprop="url"><?php bloginfo( 'name' ); ?></a>
                  <?php endif; ?>
                  <?php
                     } else {
                      the_custom_logo();
                     }
                     ?>
                  <!-- end custom logo -->
                  <!-- User login registration and myaccount area -->
                  <div class="abdask-login-button-mobile">
                     <?php if( !is_user_logged_in() ){ ?>
                     <a href="<?php echo esc_url( home_url( '/register/' ) ); ?>"><?php esc_html_e( 'Sign Up', 'abdask' ); ?></a>
                     <a href="<?php echo esc_url( home_url( '/vendor-registration/' ) ); ?>"><?php esc_html_e( 'Become a Seller', 'abdask' ); ?></a>
                     <a href="<?php echo esc_url( home_url( '/login/' ) ); ?>"><?php esc_html_e( 'Login', 'abdask' ); ?></a>
                     <?php }else{ ?>
                     <a href="<?php echo esc_url( home_url( '/my-account/' ) ); ?>">
                     <?php 
                        global $current_user;
                        wp_get_current_user();
                        echo ucwords($current_user->display_name);
                        ?> 
                     </a>
                     <?php } ?>
                  </div>
                  <!-- End. Mobile view -->
                  <!-- Mobile view -->
                  <!-- Cart button start -->
                  <div class="abdask-cart-button-mobile">
                     <a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
                     <?php echo sprintf ( _n( '%d', '%d', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?>
                     </a>
                     <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                  </div>
                  <!-- End. Cart button -->
                  <!-- Search form start -->
                  <div class="abdask-menu-search-form">
                     <?php get_product_search_form(); ?>
                  </div>
                  <!-- End. search form -->
                  <!-- User login registration and myaccount area -->
                  <div class="abdask-login-button">
                     <?php if( !is_user_logged_in() ){ ?>
                     <a href="<?php echo esc_url( home_url( '/register/' ) ); ?>"><?php esc_html_e( 'Sign Up', 'abdask' ); ?></a>
                     <a href="<?php echo esc_url( home_url( '/vendor-registration/' ) ); ?>"><?php esc_html_e( 'Become a Seller', 'abdask' ); ?></a>
                     <a href="<?php echo esc_url( home_url( '/login/' ) ); ?>"><?php esc_html_e( 'Login', 'abdask' ); ?></a>
                     <?php }else{ ?>
                     <a href="<?php echo esc_url( home_url( '/my-account/' ) ); ?>">
                     <?php 
                        global $current_user;
                        wp_get_current_user();
                        echo ucwords($current_user->display_name);
                         ?> 
                     </a>
                     <?php } ?>
                  </div>
                  <!-- Cart button start -->
                  <div class="abdask-cart-button">
                     <a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
                     <?php echo sprintf ( _n( '%d', '%d', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?>
                     </a>
                     <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                     <span><?php esc_html_e( 'Cart', 'abdask' ); ?></span>
                  </div>
                  <!-- End. Cart button -->
                  <?php if ( 'container' === $container ) : ?>
               </div>
               <!-- .container -->
               <?php endif; ?>
            </div>
            <!-- #wrapper-navbar end -->
         </nav>
         <!-- .site-navigation -->
         <!-- Product menu -->
         <div class="abdask-product-menu bg-white">
            <nav id="main-nav" class="navbar navbar-expand-md navbar-dark" aria-labelledby="main-nav-label">
               <div class="container-fluid">
                  <!-- The WordPress Menu goes here -->
                  <?php
                     wp_nav_menu(
                      array(
                        'theme_location'  => 'product-menu',
                        'container_class' => 'collapse navbar-collapse',
                        'container_id'    => 'navbarNavDropdown',
                        'menu_class'      => 'navbar-nav m-auto',
                        'fallback_cb'     => '',
                        'menu_id'         => 'product-menu',
                        'depth'           => 2,
                        'walker'          => new abdask_WP_Bootstrap_Navwalker(),
                      )
                     );
                     ?>
               </div>
               <!-- #wrapper-navbar end -->
            </nav>
            <!-- .site-navigation -->
         </div>
         <!-- End. Product menu -->
      </div>
      <!-- #wrapper-container end -->