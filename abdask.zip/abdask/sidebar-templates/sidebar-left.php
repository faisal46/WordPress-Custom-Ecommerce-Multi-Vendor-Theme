<?php
/**
 * The sidebar containing the main widget area
 *
 * @package abdask
 */

if( is_shop() ){
	$abdask_sidebar = "shop-sidebar";
}else{
	$abdask_sidebar = "left-sidebar";
}

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! is_active_sidebar( $abdask_sidebar ) ) {
	return;
}

// when both sidebars turned on reduce col size to 3 from 4.
$sidebar_pos = get_theme_mod( 'abdask_sidebar_position' );
?>

<?php
if( ! is_single() ){ ?>
	<div class="col-md-3 widget-area abdask-sidebar-layout bg-white p-0" id="left-sidebar" role="complementary">
		<?php if( is_shop() ){ ?>
		<div class="abdask-sidebar-header">
			<h2>Filters</h2>
		</div>
		<?php } ?>
		<div class="abdask-sidebar-content">
			<?php dynamic_sidebar( $abdask_sidebar ); ?>
		</div>

	</div><!-- #left-sidebar -->
<?php } ?>

