<?php
/**
 * abdask enqueue scripts
 *
 * @package abdask
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/* version check */
if( site_url() == "http://localhost/abdask" ){
	define( "VERSION", time() );
}else{
	define( "VERSION", wp_get_theme()->get( "Version" ) );
}

if ( ! function_exists( 'abdask_scripts' ) ) {
	/**
	 * Load theme's JavaScript and CSS sources.
	 */
	function abdask_scripts() {
		// Get the theme data.
		$the_theme     = wp_get_theme();
		$theme_version = $the_theme->get( 'Version' );

		$css_version = $theme_version . '.' . filemtime( get_template_directory() . '/css/theme.min.css' );
		wp_enqueue_style( 'theme', get_template_directory_uri() . '/css/theme.min.css', array(), $css_version );
		wp_enqueue_style( 'slick', get_template_directory_uri() . '/css/slick.css', array(), $css_version );
		wp_enqueue_style( 'slick-theme', get_template_directory_uri() . '/css/slick-theme.css', array(), $css_version );
		wp_enqueue_style( "dashicons" );
		wp_enqueue_style( "style", get_stylesheet_uri(), null, VERSION);
		wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css', array(), VERSION );

		wp_enqueue_script( 'jquery' );
		$js_version = $theme_version . '.' . filemtime( get_template_directory() . '/js/theme.min.js' );
		wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/js/theme.min.js', array(), $js_version, true );
		wp_enqueue_script( 'slick-scripts', get_template_directory_uri() . '/js/slick.js', array( 'jquery' ), "2.2.0", true );
		wp_enqueue_script( 'abdask-scripts', get_template_directory_uri() . '/js/abdask.js', array(), VERSION, true );
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
} // End of if function_exists( 'abdask_scripts' ).

add_action( 'wp_enqueue_scripts', 'abdask_scripts' );
