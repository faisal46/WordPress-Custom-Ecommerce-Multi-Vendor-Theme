<?php
/**
 * Custom hooks
 *
 * @package abdask
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'abdask_site_info' ) ) {
	/**
	 * Add site info hook to WP hook library.
	 */
	function abdask_site_info() {
		do_action( 'abdask_site_info' );
	}
}

add_action( 'abdask_site_info', 'abdask_add_site_info' );
if ( ! function_exists( 'abdask_add_site_info' ) ) {
	/**
	 * Add site info content.
	 */
	function abdask_add_site_info() {
		$the_theme = wp_get_theme();

		$site_info = sprintf(
			'<a href="%1$s">%2$s</a><span class="sep"> | </span>%3$s(%4$s)',
			esc_url( __( 'http://wordpress.org/', 'abdask' ) ),
			sprintf(
				/* translators: WordPress */
				esc_html__( 'Proudly powered by %s', 'abdask' ),
				'WordPress'
			),
			sprintf( // WPCS: XSS ok.
				/* translators: 1: Theme name, 2: Theme author */
				esc_html__( 'Theme: %1$s by %2$s.', 'abdask' ),
				$the_theme->get( 'Name' ),
				'<a href="' . esc_url( __( 'http://abdask.com', 'abdask' ) ) . '">abdask.com</a>'
			),
			sprintf( // WPCS: XSS ok.
				/* translators: Theme version */
				esc_html__( 'Version: %1$s', 'abdask' ),
				$the_theme->get( 'Version' )
			)
		);

		echo apply_filters( 'abdask_site_info_content', $site_info ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
