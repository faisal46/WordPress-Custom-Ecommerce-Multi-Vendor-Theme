<?php
/**
 * Left sidebar check
 *
 * @package abdask
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$sidebar_pos = get_theme_mod( 'abdask_sidebar_position' );

if ( 'left' === $sidebar_pos || 'both' === $sidebar_pos ) {
	get_template_part( 'sidebar-templates/sidebar', 'left' );
}
?>
<?php
if(is_single()){
	$page_layout = "p-3";
}else{
	$page_layout = "p-0";
}
?>
<div class="col-md content-area abdask-page-content-layout bg-white <?php echo $page_layout; ?>" id="primary">

