<?php
   /**
    * Template Name: Login Page Template
    *
    * Template for displaying a page without sidebar even if a sidebar widget is published.
    *
    * @package abdask
    */

   // Exit if accessed directly.
   defined( 'ABSPATH' ) || exit;

   get_header();

   ?>
<div class="abdask-form-page-layout pt-5 pb-5">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
           <div class="abdask-form-page-content text-center mt-5 pt-5">
               <img src="http://localhost/abdask/wp-content/uploads/2020/08/cropped-logo-4-1.png" class="img-fluid" alt="Sadid Store">
             <h3 class="text-white mt-3">The leading online shopping platform in world wide marketplace.</h3>
           </div>
         </div>
         <div class="col-md-6">
           <!-- Login form -->
            <div class="abdask-form-content">
                <?php if( !is_user_logged_in() ){ ?>
              <h3>Login</h3>
               <?php echo do_shortcode("[wc_login_form_bbloomer]"); ?>
                <?php }else{ ?>
                  <div class="text-center">
                    <h3 class="pb-3">You have logined !</h3>
                   <a class="btn btn-outline-primary" href="<?php echo esc_url( home_url( '/my-account/' ) ); ?>"><?php esc_html_e( 'My Account', 'abdask' ); ?></a>
                  </div>
                <?php } ?>
            </div>
           <!-- End. Login form -->
         </div>
      </div>
      <!-- .row end -->
   </div>
   <!-- #content -->
   <!-- End. Top offers area -->
</div>
<!-- #full-width-page-wrapper -->
<?php
get_footer();
