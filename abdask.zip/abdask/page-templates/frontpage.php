<?php
   /**
    * Template Name: Front Page Template
    *
    * Template for displaying a page without sidebar even if a sidebar widget is published.
    *
    * @package abdask
    */
   
   // Exit if accessed directly.
   defined( 'ABSPATH' ) || exit;
   
   get_header();
   
   ?>
<div class="wrapper">
   <div class="container-fluid">
      <div class="row">
         <!-- Slider area -->
         <div class="abdask-content-layout">
            <div class="abdask-slider-area">
               <?php if ( is_front_page() ) {
                  get_template_part( 'global-templates/hero' );
                  }
                  ?>
            </div>
         </div>
         <!-- End. Slider area -->
         <!-- product categories image -->
         <div class="abdask-content-layout product-cat-image">
            <div class="card">
               <div class="abdask-card-body">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="top-offers-product">
                           <section class="one-time">
                              <?php
                                 $cat_args = array(
                                              'orderby' => 'name',
                                              'order' => 'asc',
                                              'hide_empty' => true,
                                           );
                                 $product_categories = get_terms( 'product_cat', $cat_args );

                                 foreach ($product_categories as $product_category){ 
                                    $thumbnail_id = get_woocommerce_term_meta( $product_category->term_id, 'thumbnail_id', true );
                                    $thumbnail = wp_get_attachment_image_url( $thumbnail_id, 'large' );

                                    if( !$thumbnail ){
                                       continue;
                                    }

                                    if( $thumbnail ) { ?>
                                      <div class="text-center">
                                          <a href="<?php echo esc_url( get_term_link( $product_category, 'product_cat' ) ); ?>">

                                 <img src="<?php echo esc_url( $thumbnail ); ?>" alt="<?php echo esc_attr( $product_category->name ); ?>">
                                  <p class="categories-name">
                                    <?php if( $product_category->name ){
                                       echo esc_html( $product_category->name );
                                    } ?>
                                 </p>
                                 </a>
                                      </div> 

                                    <?php } ?>

                                
                              <?php } ?>
                        
                           </section>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- End. product categories image -->
      <!-- Mobile show Category area -->
         <div class="abdask-content-layout-blank category-mobile-show">
            <div class="abdask-category-area">
               <div class="row">
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/electronics/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/women.png' ); ?>" alt="Category" />
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <!-- End. Category area -->
          
         <!-- Top offers area -->
         <div class="abdask-content-layout">
            <div class="card">
               <div class="card-header abdask-card-header bg-white">
                  <h2 class="float-left"><?php esc_html_e( 'Top Offers', 'abdask' ); ?></h2>
                  <a href="<?php echo esc_url( home_url( '/product-category/top-offers/' ) ); ?>">
                  <button type="button" class="btn btn-primary float-right abdask-button">
                  <?php esc_html_e( 'VIEW ALL', 'abdask' ); ?>
                  </button>
                  </a>
               </div>
               <div class="card-body abdask-card-body">
                  <div class="row">
                     <div class="col-md-2">
                        <div class="top-offers-left mt-3">
                           <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/top-offers.jpg' ); ?>">
                        </div>
                     </div>
                     <div class="col-md-10">
                        <div class="top-offers-product">
                           <section class="top_offer_product_slider">
                              <?php
                                 $args = array(
                                              'posts_per_page' => '12',
                                              'product_cat' => 'top-offers',
                                              'post_type' => 'product',
                                              'orderby' => 'id',
                                           );
                                 
                                 
                                 $query = new WP_Query( $args );
                                 $product = wc_get_product( $post_id );
                                 if( $query->have_posts()) : while( $query->have_posts() ) : $query->the_post();
                                 ?>
                              <a href="<?php the_permalink (); ?>">
                                 <div class="text-center">
                                    <?php the_post_thumbnail('full'); ?>
                                    <h3><?php the_title(); ?></h3>
                                    <p>From 
                                       <?php 
                                          echo get_woocommerce_currency_symbol();
                                          echo $product->get_sale_price(); 
                                          ?>
                                    </p>
                                 </div>
                              </a>
                              <?php
                                 endwhile;
                                 endif;
                                 ?>
                           </section>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- End. Top offers area -->
         <!-- Category area -->
         <div class="abdask-content-layout-blank">
            <div class="abdask-category-area">
               <div class="row">
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/tvs-appliances/' ) ); ?>">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/category-2.png' ); ?>" alt="Category" />
                     </a>
                  </div>
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/electronics/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/category-3.png' ); ?>" alt="Category" />
                     </a>
                  </div>
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/home-furniture/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/category-1.png' ); ?>" alt="Category" />
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <!-- End. Category area -->
         <!-- Laptop area -->
         <div class="abdask-content-layout">
            <div class="card">
               <div class="card-header abdask-card-header bg-white">
                  <h2 class="float-left"><?php esc_html_e( 'Best on Electronics', 'abdask' ); ?></h2>
                  <a href="<?php echo esc_url( home_url( '/product-category/top-offers/' ) ); ?> ">
                  <button type="button" class="btn btn-primary float-right abdask-button">
                  <?php esc_html_e( 'VIEW ALL', 'abdask' ); ?>
                  </button>
                  </a>
               </div>
               <div class="card-body abdask-card-body">
                  <section class="laptop_product_slider">
                     <?php
                        $args = array(
                                     'posts_per_page' => '12',
                                     'product_cat' => 'electronics',
                                     'post_type' => 'product',
                                     'orderby' => 'title',
                                  );
                        
                        
                        $query = new WP_Query( $args );
                        $product = wc_get_product( $post_id );
                        if( $query->have_posts()) : while( $query->have_posts() ) : $query->the_post();
                        ?>
                     <a href="<?php the_permalink (); ?>">
                        <div class="text-center">
                           <?php the_post_thumbnail('full'); ?>
                           <h3><?php the_title(); ?></h3>
                           <p>From 
                              <?php 
                                 echo get_woocommerce_currency_symbol();
                                 echo $product->get_sale_price(); 
                                 ?>
                           </p>
                        </div>
                     </a>
                     <?php
                        endwhile;
                        endif;
                        ?>
                  </section>
               </div>
            </div>
         </div>
         <!-- .End. Laptop area -->
         <!-- Home & furniture area -->
         <div class="abdask-content-layout">
            <div class="card">
               <div class="card-header abdask-card-header bg-white">
                  <h2 class="float-left"><?php esc_html_e( 'Mega Sale', 'abdask' ); ?></h2>
                  <a href="<?php echo esc_url( home_url( '/product-category/top-offers/' ) ); ?>">
                  <button type="button" class="btn btn-primary float-right abdask-button">
                  <?php esc_html_e( 'VIEW ALL', 'abdask' ); ?>
                  </button>
                  </a>
               </div>
               <div class="card-body abdask-card-body">
                  <section class="laptop_product_slider">
                     <?php
                        $args = array(
                                     'posts_per_page' => '12',
                                     'product_cat' => 'mega-sale',
                                     'post_type' => 'product',
                                     'orderby' => 'title',
                                  );
                        
                        
                        $query = new WP_Query( $args );
                        $product = wc_get_product( $post_id );
                        if( $query->have_posts()) : while( $query->have_posts() ) : $query->the_post();
                        ?>
                     <a href="<?php the_permalink (); ?>">
                        <div class="text-center">
                           <?php the_post_thumbnail('full'); ?>
                           <h3><?php the_title(); ?></h3>
                           <p>From 
                              <?php 
                                 echo get_woocommerce_currency_symbol();
                                 echo $product->get_sale_price(); 
                                 ?>
                           </p>
                        </div>
                     </a>
                     <?php
                        endwhile;
                        endif;
                        ?>
                  </section>
               </div>
            </div>
         </div>
         <!-- .End. Home & furniture area -->
         <!-- Category area -->
         <div class="abdask-content-layout-blank">
            <div class="abdask-category-area">
               <div class="row">
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/tvs-appliances/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/baby-kids.png' ); ?>" alt="Category" />
                     </a>
                  </div>
                  <div class="col-md-4 abdask-category-inner">
                     <a href="<?php echo esc_url( home_url( '/product-category/electronics/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/women.png' ); ?>" alt="Category" />
                     </a>
                  </div>
                  <div class="col-md-4 abdask-category-inner">

					<a href="<?php echo esc_url( home_url( '/product-category/home-furniture/' ) ); ?> ">
                     <img src="<?php echo esc_url( 'http://abdask.com/wp-content/uploads/2020/08/category-1.png' ); ?>" alt="Category" />
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <!-- End. Category area -->
         <!-- Baby & kids area -->
         <div class="abdask-content-layout">
            <div class="card">
               <div class="card-header abdask-card-header bg-white">
                  <h2 class="float-left"><?php esc_html_e( 'Hot Deals', 'abdask' ); ?></h2>
                  <a href="<?php echo esc_url( home_url( '/product-category/top-offers/' ) ); ?> ">
                  <button type="button" class="btn btn-primary float-right abdask-button">
                  <?php esc_html_e( 'VIEW ALL', 'abdask' ); ?>
                  </button>
                  </a>
               </div>
               <div class="card-body abdask-card-body">
                  <section class="laptop_product_slider">
                     <?php
                        $args = array(
                                     'posts_per_page' => '12',
                                     'product_cat' => 'hot-deals',
                                     'post_type' => 'product',
                                     'orderby' => 'id',
                                  );
                        
                        
                        $query = new WP_Query( $args );
                        $product = wc_get_product( $post_id );
                        if( $query->have_posts()) : while( $query->have_posts() ) : $query->the_post();
                        ?>
                     <a href="<?php the_permalink (); ?>">
                        <div class="text-center">
                           <?php the_post_thumbnail('full'); ?>
                           <h3><?php the_title(); ?></h3>
                           <p>From 
                              <?php 
                                 echo get_woocommerce_currency_symbol();
                                 echo $product->get_sale_price(); 
                                 ?>
                           </p>
                        </div>
                     </a>
                     <?php
                        endwhile;
                        endif;
                        ?>
                  </section>
               </div>
            </div>
         </div>
         <!-- .End. Baby & kids area -->
         <!-- Tvs-appliances area -->
         <div class="abdask-content-layout">
            <div class="card">
               <div class="card-header abdask-card-header bg-white">
                  <h2 class="float-left"><?php esc_html_e( 'Flash Sale', 'abdask' ); ?></h2>
                  <a href="<?php echo esc_url( home_url( '/product-category/top-offers/' ) ); ?> ">
                  <button type="button" class="btn btn-primary float-right abdask-button">
                  <?php esc_html_e( 'VIEW ALL', 'abdask' ); ?>
                  </button>
                  </a>
               </div>
               <div class="card-body abdask-card-body">
                  <section class="laptop_product_slider">
                     <?php
                        $args = array(
                                     'posts_per_page' => '12',
                                     'product_cat' => 'flash-sale',
                                     'post_type' => 'product',
                                     'orderby' => 'title',
                                  );
                        
                        
                        $query = new WP_Query( $args );
                        $product = wc_get_product( $post_id );
                        if( $query->have_posts()) : while( $query->have_posts() ) : $query->the_post();
                        ?>
                     <a href="<?php the_permalink (); ?>">
                        <div class="text-center">
                           <?php the_post_thumbnail('full'); ?>
                           <h3><?php the_title(); ?></h3>
                           <p>From 
                              <?php 
                                 echo get_woocommerce_currency_symbol();
                                 echo $product->get_sale_price(); 
                                 ?>
                           </p>
                        </div>
                     </a>
                     <?php
                        endwhile;
                        endif;
                        ?>
                  </section>
               </div>
            </div>
         </div>
         <!-- .End. Tvs-appliances area -->
      </div>
      <!-- .row end -->
   </div>
   <!-- #content -->
   <!-- End. Top offers area -->
</div>
<!-- #full-width-page-wrapper -->
<?php
get_footer();