<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package abdask
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<div class="abdask-footer-area">
<div class="wrapper abdask-footer-top" id="wrapper-footer-full">

		<div class="<?php echo esc_attr( $container ); ?>" id="footer-full-content" tabindex="-1">

			<div class="row ml-5 mr-5">

				<div class="col-md-2">
					<?php
					   if ( is_active_sidebar( 'footerone' ) ) {
					    dynamic_sidebar( 'footerone' );
					   }
					?>
				</div>
				<div class="col-md-2">
					<?php
					   if ( is_active_sidebar( 'footertwo' ) ) {
					    dynamic_sidebar( 'footertwo' );
					   }
					?>
				</div>
				<div class="col-md-2">
					<?php
					   if ( is_active_sidebar( 'footerthree' ) ) {
					    dynamic_sidebar( 'footerthree' );
					   }
					?>
				</div>
				<div class="col-md-2">
					<?php
					   if ( is_active_sidebar( 'footerfour' ) ) {
					    dynamic_sidebar( 'footerfour' );
					   }
					?>
				</div>
				<div class="col-md-2 abdask-mail-us">
					<?php
					   if ( is_active_sidebar( 'footerfive' ) ) {
					    dynamic_sidebar( 'footerfive' );
					   }
					?>
				</div>
				<div class="col-md-2 abdask-register-office">
					<?php
					   if ( is_active_sidebar( 'footersix' ) ) {
					    dynamic_sidebar( 'footersix' );
					   }
					?>
				</div>

			</div>

		</div>

	</div><!-- #wrapper-footer-full -->

<div class="wrapper abdask-footer-bottom" id="wrapper-footer">

	<div class="container-fluid">

		<div class="row ml-5 mr-5">

			<div class="col-md-6">
				<nav id="footer-nav" class="navbar navbar-expand-md navbar-dark" aria-labelledby="main-nav-label">
				<!-- The WordPress Menu goes here -->
						<?php
						wp_nav_menu(
							array(
								'theme_location'  => 'footer-menu',
								'container_class' => 'navbar-collapse',
								'container_id'    => 'navbarNavDropdown',
								'menu_class'      => 'navbar-nav',
								'fallback_cb'     => '',
								'menu_id'         => 'footer-menu',
								'depth'           => 2,
								'walker'          => new abdask_WP_Bootstrap_Navwalker(),
							)
						);
						?>
			</nav><!-- .site-navigation -->
			</div><!--col end -->

			<div class="col-md-2">
					<?php
					   if ( is_active_sidebar( 'footercoppywrite' ) ) {
					    dynamic_sidebar( 'footercoppywrite' );
					   }
					?>
			</div><!--col end -->

			<div class="col-md-4">
				<?php
					if ( is_active_sidebar( 'footerpayment' ) ) {
					   dynamic_sidebar( 'footerpayment' );
					}
				?>
					   
			</div><!--col end -->

		</div><!-- row end -->

	</div><!-- container end -->

</div><!-- wrapper end -->
</div><!-- Footer area end -->

</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>

</body>

</html>

